# easytax

## OpenAPI 3.0 Generated NodeJS Express

This project contains generated code from an OpenAPI 3 definition.
The project integrate the NodeJS express library and is ready to run stand alone as a service.

To run this project:
```
npm install
npm run start
```