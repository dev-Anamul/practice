module.exports = function (app) {
  /*
  * Routes
  */
  app.use('/admin', require('./routes/admin.route'));
  app.use('/assets', require('./routes/assets.route'));
  app.use('/auth', require('./routes/auth.route'));
  app.use('/categories', require('./routes/categories.route'));
  app.use('/dashboard', require('./routes/dashboard.route'));
  app.use('/depreciation', require('./routes/depreciation.route'));
  app.use('/expenses', require('./routes/expenses.route'));
  app.use('/fiscal-years', require('./routes/fiscal-years.route'));
  app.use('/income-sources', require('./routes/income-sources.route'));
  app.use('/income-types', require('./routes/income-types.route'));
  app.use('/notifications', require('./routes/notifications.route'));
  app.use('/ocr-expenses', require('./routes/ocr-expenses.route'));
  app.use('/reports', require('./routes/reports.route'));
  app.use('/settings', require('./routes/settings.route'));
  app.use('/support-messages', require('./routes/support-messages.route'));
  app.use('/tax', require('./routes/tax.route'));
  app.use('/tax-slabs', require('./routes/tax-slabs.route'));

};
